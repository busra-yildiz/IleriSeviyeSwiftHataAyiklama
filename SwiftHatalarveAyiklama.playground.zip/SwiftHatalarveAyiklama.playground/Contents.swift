import UIKit

//if yapısının tam tersi olarak akılda tutmak yeterli olacaktır.

//Hata ayıklama için iki farklı durum vardır. Bunlar;
//1. Compile Error: Biz kodlama yaparken editör tarafından verilen hatalardır. Yani editör hataları olarak bilinir. Örneğin;

// let x = 10 burada xi  sabir olarak 10 şeklinde atadır.
// x = 40 fakat bu satırda sabit olan bir şeyi 40 olarak değiştirmek istedik diye compile error hatası verir.

//hatalardan bir diğeri de runtime error olarak devreye girer. Çalışma sırasında oluşan hatalar olarak bilinir. Kodlama yapılırken hata gözükmüyor olsa bile run etme sırasında meydana gelen hataları kapsar. Yani;
 // let sonuc = 10 / 0   //satırı yazdığımız zaman yanda kırmızı çarpı işareti ile hata çıkmadığı anlar olabilir. Fakar run ettiğimiz zaman altta yer alan ekran çıktısı kısmında expression failed to parse: error: IleriSeviyeSwift.playground:35:17: error: division by zero let sonuc = 10 / 0 yazan hata görebiliyoruz. Bu kısma verilen isimdir. Kodlama sırasında sorun olmasa bile run edildiği an uygulama çöker. Bunun için farklı yöntemler vardır ve onları kullanırız. Hataları çözmek için;

enum Hatalar : Error {
    case sifiraBolunmeHatasi

}
func bolme(sayi1:Int, sayi2:Int)throws -> Int{
    if sayi2 == 0{
        throw Hatalar.sifiraBolunmeHatasi
    }
    return sayi1 / sayi2
}
do {
let sonuc = try bolme(sayi1: 10, sayi2: 0)
    print(sonuc)
}catch Hatalar.sifiraBolunmeHatasi{
    print("Sayı Sıfıra Bölünemez")
}
 //bir hata ayıklama yöntemi olarak da;
let sonuc1 = try? bolme(sayi1: 10, sayi2: 0) //eğer bu şekilde yazarsak ve hata verirse sonuç nil olur anlamına gelir.

if let temp = sonuc1 {
    print(temp)
    
} else {
    print("Sayı 0a bölünemez")
}
